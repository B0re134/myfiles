#!/bin/bash

echo "🎰 BetPlatform Setup Script"
echo "================================"
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker not found. Please install Docker first."
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose not found. Please install Docker Compose first."
    exit 1
fi

echo "✅ Docker and Docker Compose found"
echo ""

# Copy environment files
echo "📝 Setting up environment files..."
cp backend/.env.example backend/.env
echo "VITE_API_URL=http://localhost:5000/api" > frontend/.env
echo "✅ Environment files created"
echo ""

# Start services
echo "🚀 Starting services with Docker Compose..."
docker-compose up -d

# Wait for database to be ready
echo "⏳ Waiting for database to be ready..."
sleep 10

# Run database migrations
echo "📊 Running database migrations..."
docker-compose exec -T backend npx prisma migrate dev --name init

echo ""
echo "✅ Setup complete!"
echo ""
echo "Access the platform:"
echo "  Frontend: http://localhost:5173"
echo "  Backend:  http://localhost:5000"
echo ""
echo "To create an admin user, run:"
echo "  docker-compose exec backend npm run create-admin"
echo ""
echo "To view logs:"
echo "  docker-compose logs -f"
echo ""
echo "To stop services:"
echo "  docker-compose down"
echo ""
echo "⚠️  IMPORTANT: This is for development/educational use only."
echo "    Do NOT use for real money without proper licensing!"
