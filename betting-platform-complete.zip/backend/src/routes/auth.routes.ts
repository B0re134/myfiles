import { Router } from 'express';
import { body } from 'express-validator';
import { AuthController } from '../controllers/auth.controller';
import { validate } from '../middleware/validation';
import { authenticate } from '../middleware/auth';

const router = Router();
const authController = new AuthController();

// Register
router.post(
  '/register',
  validate([
    body('email').isEmail().normalizeEmail(),
    body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
    body('firstName').trim().notEmpty(),
    body('lastName').trim().notEmpty(),
    body('dateOfBirth').isISO8601().toDate(),
    body('country').trim().notEmpty(),
    body('phoneNumber').optional().trim(),
  ]),
  authController.register.bind(authController)
);

// Login
router.post(
  '/login',
  validate([
    body('email').isEmail().normalizeEmail(),
    body('password').notEmpty(),
  ]),
  authController.login.bind(authController)
);

// Refresh token
router.post(
  '/refresh',
  validate([body('refreshToken').notEmpty()]),
  authController.refreshToken.bind(authController)
);

// Logout (requires auth)
router.post('/logout', authenticate, authController.logout.bind(authController));

// Logout all devices
router.post('/logout-all', authenticate, authController.logoutAll.bind(authController));

// Get current user
router.get('/me', authenticate, authController.me.bind(authController));

export default router;
