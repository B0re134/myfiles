import { Router } from 'express';
import { body } from 'express-validator';
import { AdminController } from '../controllers/admin.controller';
import { validate } from '../middleware/validation';
import { authenticate, requireRole } from '../middleware/auth';

const router = Router();
const adminController = new AdminController();

// All admin routes require authentication and admin role
router.use(authenticate);
router.use(requireRole('ADMIN', 'SUPER_ADMIN'));

// Dashboard stats
router.get('/dashboard/stats', adminController.getDashboardStats.bind(adminController));

// User management
router.get('/users', adminController.getUsers.bind(adminController));
router.get('/users/:userId', adminController.getUser.bind(adminController));
router.patch(
  '/users/:userId/status',
  validate([body('status').isIn(['PENDING_VERIFICATION', 'ACTIVE', 'SUSPENDED', 'SELF_EXCLUDED', 'PERMANENTLY_BANNED'])]),
  adminController.updateUserStatus.bind(adminController)
);

// KYC management
router.post('/users/:userId/kyc/approve', adminController.approveKYC.bind(adminController));
router.post(
  '/users/:userId/kyc/reject',
  validate([body('reason').trim().notEmpty()]),
  adminController.rejectKYC.bind(adminController)
);

// Withdrawal approvals
router.post('/transactions/:transactionId/approve', adminController.approveWithdrawal.bind(adminController));

// Audit logs
router.get('/audit-logs', adminController.getAuditLogs.bind(adminController));

export default router;
