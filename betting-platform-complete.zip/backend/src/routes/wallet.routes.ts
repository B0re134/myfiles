import { Router } from 'express';
import { body } from 'express-validator';
import { WalletController } from '../controllers/wallet.controller';
import { validate } from '../middleware/validation';
import { authenticate } from '../middleware/auth';

const router = Router();
const walletController = new WalletController();

// All wallet routes require authentication
router.use(authenticate);

// Get wallet details
router.get('/', walletController.getWallet.bind(walletController));

// Get balance
router.get('/balance', walletController.getBalance.bind(walletController));

// Deposit
router.post(
  '/deposit',
  validate([
    body('amount').isFloat({ min: 1 }).withMessage('Amount must be at least 1'),
    body('paymentMethod').trim().notEmpty(),
  ]),
  walletController.deposit.bind(walletController)
);

// Withdraw
router.post(
  '/withdraw',
  validate([
    body('amount').isFloat({ min: 1 }).withMessage('Amount must be at least 1'),
    body('paymentMethod').trim().notEmpty(),
  ]),
  walletController.withdraw.bind(walletController)
);

// Get transaction history
router.get('/transactions', walletController.getTransactions.bind(walletController));

export default router;
