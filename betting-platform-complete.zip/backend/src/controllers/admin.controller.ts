import { Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth';
import prisma from '../config/database';
import { AuditService } from '../services/audit.service';
import { NotFoundError } from '../utils/errors';

const auditService = new AuditService();

export class AdminController {
  async getUsers(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const status = req.query.status as string;

      const where: any = {};
      if (status) where.status = status;

      const [users, total] = await Promise.all([
        prisma.user.findMany({
          where,
          select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
            country: true,
            role: true,
            status: true,
            kycStatus: true,
            createdAt: true,
            lastLogin: true,
            wallet: {
              select: {
                balance: true,
                totalDeposited: true,
                totalWithdrawn: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
          take: limit,
          skip: offset,
        }),
        prisma.user.count({ where }),
      ]);

      res.json({
        success: true,
        data: { users, total },
      });
    } catch (error) {
      next(error);
    }
  }

  async getUser(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const { userId } = req.params;

      const user = await prisma.user.findUnique({
        where: { id: userId },
        include: {
          wallet: true,
          transactions: {
            orderBy: { createdAt: 'desc' },
            take: 20,
          },
          bets: {
            orderBy: { createdAt: 'desc' },
            take: 20,
          },
          kycDocuments: true,
        },
      });

      if (!user) {
        throw new NotFoundError('User not found');
      }

      res.json({
        success: true,
        data: { user },
      });
    } catch (error) {
      next(error);
    }
  }

  async updateUserStatus(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const { userId } = req.params;
      const { status } = req.body;

      const user = await prisma.user.update({
        where: { id: userId },
        data: { status },
      });

      await auditService.log({
        userId: req.userId,
        action: 'USER_STATUS_UPDATED',
        entityType: 'USER',
        entityId: userId,
        details: { newStatus: status },
        riskLevel: 'HIGH',
        flagged: true,
      });

      res.json({
        success: true,
        data: { user },
      });
    } catch (error) {
      next(error);
    }
  }

  async approveKYC(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const { userId } = req.params;

      const user = await prisma.user.update({
        where: { id: userId },
        data: { kycStatus: 'APPROVED' },
      });

      await auditService.log({
        userId: req.userId,
        action: 'KYC_APPROVED',
        entityType: 'USER',
        entityId: userId,
        details: { approvedBy: req.userId },
        riskLevel: 'HIGH',
      });

      res.json({
        success: true,
        message: 'KYC approved',
        data: { user },
      });
    } catch (error) {
      next(error);
    }
  }

  async rejectKYC(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const { userId } = req.params;
      const { reason } = req.body;

      const user = await prisma.user.update({
        where: { id: userId },
        data: { kycStatus: 'REJECTED' },
      });

      await auditService.log({
        userId: req.userId,
        action: 'KYC_REJECTED',
        entityType: 'USER',
        entityId: userId,
        details: { rejectedBy: req.userId, reason },
        riskLevel: 'HIGH',
      });

      res.json({
        success: true,
        message: 'KYC rejected',
        data: { user },
      });
    } catch (error) {
      next(error);
    }
  }

  async getDashboardStats(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const [
        totalUsers,
        activeUsers,
        pendingKYC,
        todayDeposits,
        todayWithdrawals,
        totalBets,
      ] = await Promise.all([
        prisma.user.count(),
        prisma.user.count({ where: { status: 'ACTIVE' } }),
        prisma.user.count({ where: { kycStatus: 'PENDING' } }),
        prisma.transaction.aggregate({
          where: {
            type: 'DEPOSIT',
            status: 'COMPLETED',
            createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) },
          },
          _sum: { amount: true },
          _count: true,
        }),
        prisma.transaction.aggregate({
          where: {
            type: 'WITHDRAWAL',
            status: 'COMPLETED',
            createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) },
          },
          _sum: { amount: true },
          _count: true,
        }),
        prisma.bet.count(),
      ]);

      res.json({
        success: true,
        data: {
          users: {
            total: totalUsers,
            active: activeUsers,
            pendingKYC,
          },
          today: {
            deposits: {
              amount: todayDeposits._sum.amount || 0,
              count: todayDeposits._count,
            },
            withdrawals: {
              amount: todayWithdrawals._sum.amount || 0,
              count: todayWithdrawals._count,
            },
          },
          bets: {
            total: totalBets,
          },
        },
      });
    } catch (error) {
      next(error);
    }
  }

  async getAuditLogs(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const offset = parseInt(req.query.offset as string) || 0;
      const flagged = req.query.flagged === 'true';

      const result = await auditService.getLogs({
        flagged,
        limit,
        offset,
      });

      res.json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  }

  async approveWithdrawal(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const { transactionId } = req.params;

      const transaction = await prisma.transaction.update({
        where: { id: transactionId },
        data: { status: 'COMPLETED' },
      });

      await auditService.log({
        userId: req.userId,
        action: 'WITHDRAWAL_APPROVED',
        entityType: 'TRANSACTION',
        entityId: transactionId,
        details: { approvedBy: req.userId },
        riskLevel: 'HIGH',
      });

      res.json({
        success: true,
        message: 'Withdrawal approved',
        data: { transaction },
      });
    } catch (error) {
      next(error);
    }
  }
}
