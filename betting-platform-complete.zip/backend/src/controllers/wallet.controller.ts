import { Response, NextFunction } from 'express';
import { WalletService } from '../services/wallet.service';
import { AuthRequest } from '../middleware/auth';

const walletService = new WalletService();

export class WalletController {
  async getWallet(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.userId) {
        throw new Error('User not authenticated');
      }

      const wallet = await walletService.getWallet(req.userId);

      res.json({
        success: true,
        data: { wallet },
      });
    } catch (error) {
      next(error);
    }
  }

  async getBalance(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.userId) {
        throw new Error('User not authenticated');
      }

      const balance = await walletService.getBalance(req.userId);

      res.json({
        success: true,
        data: { balance },
      });
    } catch (error) {
      next(error);
    }
  }

  async deposit(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.userId) {
        throw new Error('User not authenticated');
      }

      const { amount, paymentMethod } = req.body;
      const ipAddress = req.ip || req.socket.remoteAddress || 'unknown';

      const result = await walletService.deposit(
        req.userId,
        parseFloat(amount),
        paymentMethod,
        ipAddress
      );

      res.json({
        success: true,
        message: 'Deposit successful',
        data: result,
      });
    } catch (error) {
      next(error);
    }
  }

  async withdraw(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.userId) {
        throw new Error('User not authenticated');
      }

      const { amount, paymentMethod } = req.body;
      const ipAddress = req.ip || req.socket.remoteAddress || 'unknown';

      const result = await walletService.withdraw(
        req.userId,
        parseFloat(amount),
        paymentMethod,
        ipAddress
      );

      res.json({
        success: true,
        message: 'Withdrawal request submitted (pending approval)',
        data: result,
      });
    } catch (error) {
      next(error);
    }
  }

  async getTransactions(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.userId) {
        throw new Error('User not authenticated');
      }

      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;

      const transactions = await walletService.getTransactions(
        req.userId,
        limit,
        offset
      );

      res.json({
        success: true,
        data: { transactions },
      });
    } catch (error) {
      next(error);
    }
  }
}
