import prisma from '../config/database';
import { Decimal } from '@prisma/client/runtime/library';
import {
  InsufficientFundsError,
  NotFoundError,
  KYCRequiredError,
  ValidationError,
} from '../utils/errors';
import { AuditService } from './audit.service';
import { TransactionType, TransactionStatus } from '@prisma/client';

interface TransactionData {
  userId: string;
  type: TransactionType;
  amount: number;
  description?: string;
  metadata?: any;
  ipAddress?: string;
}

export class WalletService {
  private auditService = new AuditService();

  async getWallet(userId: string) {
    const wallet = await prisma.wallet.findUnique({
      where: { userId },
    });

    if (!wallet) {
      throw new NotFoundError('Wallet not found');
    }

    return wallet;
  }

  async getBalance(userId: string): Promise<number> {
    const wallet = await this.getWallet(userId);
    return parseFloat(wallet.balance.toString());
  }

  async deposit(
    userId: string,
    amount: number,
    paymentMethod: string,
    ipAddress: string
  ): Promise<any> {
    if (amount <= 0) {
      throw new ValidationError('Deposit amount must be greater than 0');
    }

    // Check KYC for large deposits
    const maxWithoutKYC = parseFloat(process.env.MAX_DEPOSIT_WITHOUT_KYC || '1000');
    if (amount > maxWithoutKYC) {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { kycStatus: true },
      });

      if (user?.kycStatus !== 'APPROVED') {
        throw new KYCRequiredError(
          `KYC verification required for deposits over ${maxWithoutKYC}`
        );
      }
    }

    // Check deposit limits
    await this.checkDepositLimit(userId, amount);

    // Process deposit in transaction
    const result = await prisma.$transaction(async (tx) => {
      const wallet = await tx.wallet.findUnique({
        where: { userId },
      });

      if (!wallet) {
        throw new NotFoundError('Wallet not found');
      }

      const balanceBefore = parseFloat(wallet.balance.toString());
      const balanceAfter = balanceBefore + amount;

      // Update wallet
      const updatedWallet = await tx.wallet.update({
        where: { userId },
        data: {
          balance: balanceAfter,
          totalDeposited: {
            increment: amount,
          },
        },
      });

      // Create transaction record
      const transaction = await tx.transaction.create({
        data: {
          userId,
          type: 'DEPOSIT',
          status: 'COMPLETED',
          amount,
          currency: wallet.currency,
          paymentMethod,
          balanceBefore,
          balanceAfter,
          description: `Deposit via ${paymentMethod}`,
          ipAddress,
        },
      });

      return { wallet: updatedWallet, transaction };
    });

    // Audit log
    await this.auditService.log({
      userId,
      action: 'DEPOSIT',
      entityType: 'TRANSACTION',
      entityId: result.transaction.id,
      ipAddress,
      details: {
        amount,
        paymentMethod,
        transactionId: result.transaction.id,
      },
    });

    return result;
  }

  async withdraw(
    userId: string,
    amount: number,
    paymentMethod: string,
    ipAddress: string
  ): Promise<any> {
    if (amount <= 0) {
      throw new ValidationError('Withdrawal amount must be greater than 0');
    }

    // KYC required for withdrawals
    const kycRequired = process.env.KYC_REQUIRED_FOR_WITHDRAWAL === 'true';
    if (kycRequired) {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { kycStatus: true },
      });

      if (user?.kycStatus !== 'APPROVED') {
        throw new KYCRequiredError('KYC verification required for withdrawals');
      }
    }

    // Process withdrawal in transaction
    const result = await prisma.$transaction(async (tx) => {
      const wallet = await tx.wallet.findUnique({
        where: { userId },
      });

      if (!wallet) {
        throw new NotFoundError('Wallet not found');
      }

      const balanceBefore = parseFloat(wallet.balance.toString());

      if (balanceBefore < amount) {
        throw new InsufficientFundsError(
          `Insufficient funds. Available: ${balanceBefore}, Requested: ${amount}`
        );
      }

      const balanceAfter = balanceBefore - amount;

      // Update wallet
      const updatedWallet = await tx.wallet.update({
        where: { userId },
        data: {
          balance: balanceAfter,
          totalWithdrawn: {
            increment: amount,
          },
        },
      });

      // Create transaction record (pending approval)
      const transaction = await tx.transaction.create({
        data: {
          userId,
          type: 'WITHDRAWAL',
          status: 'PENDING', // Requires admin approval
          amount,
          currency: wallet.currency,
          paymentMethod,
          balanceBefore,
          balanceAfter,
          description: `Withdrawal via ${paymentMethod}`,
          ipAddress,
        },
      });

      return { wallet: updatedWallet, transaction };
    });

    // Audit log
    await this.auditService.log({
      userId,
      action: 'WITHDRAWAL_REQUESTED',
      entityType: 'TRANSACTION',
      entityId: result.transaction.id,
      ipAddress,
      details: {
        amount,
        paymentMethod,
        transactionId: result.transaction.id,
      },
      riskLevel: amount > 1000 ? 'HIGH' : 'MEDIUM',
      flagged: amount > 5000,
    });

    return result;
  }

  async getTransactions(
    userId: string,
    limit: number = 50,
    offset: number = 0
  ) {
    return await prisma.transaction.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
    });
  }

  private async checkDepositLimit(userId: string, amount: number): Promise<void> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        depositLimit: true,
        depositLimitPeriod: true,
      },
    });

    if (!user?.depositLimit || !user.depositLimitPeriod) {
      return; // No limit set
    }

    // Calculate period start
    const now = new Date();
    let periodStart = new Date();

    switch (user.depositLimitPeriod) {
      case 'DAILY':
        periodStart.setHours(0, 0, 0, 0);
        break;
      case 'WEEKLY':
        periodStart.setDate(now.getDate() - now.getDay());
        periodStart.setHours(0, 0, 0, 0);
        break;
      case 'MONTHLY':
        periodStart.setDate(1);
        periodStart.setHours(0, 0, 0, 0);
        break;
    }

    // Calculate total deposits in period
    const deposits = await prisma.transaction.aggregate({
      where: {
        userId,
        type: 'DEPOSIT',
        status: 'COMPLETED',
        createdAt: {
          gte: periodStart,
        },
      },
      _sum: {
        amount: true,
      },
    });

    const totalDeposited = deposits._sum.amount
      ? parseFloat(deposits._sum.amount.toString())
      : 0;
    const limit = parseFloat(user.depositLimit.toString());

    if (totalDeposited + amount > limit) {
      throw new ValidationError(
        `Deposit limit exceeded. Limit: ${limit} ${user.depositLimitPeriod}, Already deposited: ${totalDeposited}`
      );
    }
  }
}
