import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import prisma from '../config/database';
import {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshToken,
} from '../utils/jwt';
import {
  UnauthorizedError,
  ConflictError,
  ValidationError,
  ComplianceError,
} from '../utils/errors';
import { AuditService } from './audit.service';
import { UserStatus, UserRole } from '@prisma/client';

interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  dateOfBirth: Date;
  country: string;
  phoneNumber?: string;
  ipAddress: string;
  userAgent: string;
}

interface LoginData {
  email: string;
  password: string;
  ipAddress: string;
  userAgent: string;
}

interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: string;
}

export class AuthService {
  private auditService = new AuditService();

  async register(data: RegisterData): Promise<{ user: any; tokens: AuthTokens }> {
    // Check age requirement
    const age = this.calculateAge(data.dateOfBirth);
    const minAge = parseInt(process.env.MIN_AGE || '18');
    
    if (age < minAge) {
      throw new ComplianceError(`You must be at least ${minAge} years old to register`);
    }

    // Check if user exists
    const existingUser = await prisma.user.findUnique({
      where: { email: data.email.toLowerCase() },
    });

    if (existingUser) {
      throw new ConflictError('Email already registered');
    }

    // Hash password
    const passwordHash = await bcrypt.hash(
      data.password,
      parseInt(process.env.BCRYPT_ROUNDS || '12')
    );

    // Create user and wallet in transaction
    const user = await prisma.$transaction(async (tx) => {
      const newUser = await tx.user.create({
        data: {
          email: data.email.toLowerCase(),
          passwordHash,
          firstName: data.firstName,
          lastName: data.lastName,
          dateOfBirth: data.dateOfBirth,
          country: data.country,
          phoneNumber: data.phoneNumber,
          lastLoginIp: data.ipAddress,
        },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          role: true,
          status: true,
          kycStatus: true,
          createdAt: true,
        },
      });

      // Create wallet
      await tx.wallet.create({
        data: {
          userId: newUser.id,
          balance: 0,
          currency: 'USD',
        },
      });

      return newUser;
    });

    // Create session and generate tokens
    const tokens = await this.createSession(
      user.id,
      user.email,
      user.role,
      data.ipAddress,
      data.userAgent
    );

    // Audit log
    await this.auditService.log({
      userId: user.id,
      action: 'USER_REGISTERED',
      entityType: 'USER',
      entityId: user.id,
      ipAddress: data.ipAddress,
      userAgent: data.userAgent,
      details: {
        email: user.email,
        country: data.country,
      },
    });

    return { user, tokens };
  }

  async login(data: LoginData): Promise<{ user: any; tokens: AuthTokens }> {
    // Find user
    const user = await prisma.user.findUnique({
      where: { email: data.email.toLowerCase() },
      select: {
        id: true,
        email: true,
        passwordHash: true,
        firstName: true,
        lastName: true,
        role: true,
        status: true,
        kycStatus: true,
        selfExclusionUntil: true,
      },
    });

    if (!user) {
      throw new UnauthorizedError('Invalid credentials');
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(data.password, user.passwordHash);
    if (!isValidPassword) {
      throw new UnauthorizedError('Invalid credentials');
    }

    // Check account status
    if (user.status === 'SUSPENDED') {
      throw new ComplianceError('Account is suspended. Please contact support.');
    }

    if (user.status === 'PERMANENTLY_BANNED') {
      throw new ComplianceError('Account is permanently banned.');
    }

    // Check self-exclusion
    if (user.selfExclusionUntil && user.selfExclusionUntil > new Date()) {
      throw new ComplianceError(
        `Account is self-excluded until ${user.selfExclusionUntil.toLocaleDateString()}`
      );
    }

    // Update last login
    await prisma.user.update({
      where: { id: user.id },
      data: {
        lastLogin: new Date(),
        lastLoginIp: data.ipAddress,
      },
    });

    // Create session and generate tokens
    const tokens = await this.createSession(
      user.id,
      user.email,
      user.role,
      data.ipAddress,
      data.userAgent
    );

    // Audit log
    await this.auditService.log({
      userId: user.id,
      action: 'USER_LOGIN',
      entityType: 'USER',
      entityId: user.id,
      ipAddress: data.ipAddress,
      userAgent: data.userAgent,
    });

    const { passwordHash, ...userWithoutPassword } = user;

    return { user: userWithoutPassword, tokens };
  }

  async refreshToken(refreshToken: string): Promise<AuthTokens> {
    const payload = verifyRefreshToken(refreshToken);

    // Verify session
    const session = await prisma.session.findUnique({
      where: { refreshToken },
    });

    if (!session || !session.isActive) {
      throw new UnauthorizedError('Invalid refresh token');
    }

    // Generate new tokens
    const newAccessToken = generateAccessToken({
      userId: payload.userId,
      email: payload.email,
      role: payload.role,
      sessionId: session.id,
    });

    const newRefreshToken = generateRefreshToken({
      userId: payload.userId,
      email: payload.email,
      role: payload.role,
      sessionId: session.id,
    });

    // Update session with new refresh token
    await prisma.session.update({
      where: { id: session.id },
      data: {
        refreshToken: newRefreshToken,
        lastActivityAt: new Date(),
      },
    });

    return {
      accessToken: newAccessToken,
      refreshToken: newRefreshToken,
      expiresIn: process.env.JWT_EXPIRES_IN || '15m',
    };
  }

  async logout(token: string): Promise<void> {
    await prisma.session.update({
      where: { token },
      data: { isActive: false },
    });
  }

  async logoutAll(userId: string): Promise<void> {
    await prisma.session.updateMany({
      where: { userId },
      data: { isActive: false },
    });
  }

  private async createSession(
    userId: string,
    email: string,
    role: UserRole,
    ipAddress: string,
    userAgent: string
  ): Promise<AuthTokens> {
    const sessionId = uuidv4();

    const accessToken = generateAccessToken({
      userId,
      email,
      role,
      sessionId,
    });

    const refreshToken = generateRefreshToken({
      userId,
      email,
      role,
      sessionId,
    });

    // Calculate expiry
    const expiresIn = process.env.JWT_REFRESH_EXPIRES_IN || '7d';
    const expiresAt = new Date();
    const days = parseInt(expiresIn.replace('d', ''));
    expiresAt.setDate(expiresAt.getDate() + days);

    // Create session
    await prisma.session.create({
      data: {
        id: sessionId,
        userId,
        token: accessToken,
        refreshToken,
        ipAddress,
        userAgent,
        expiresAt,
      },
    });

    return {
      accessToken,
      refreshToken,
      expiresIn: process.env.JWT_EXPIRES_IN || '15m',
    };
  }

  private calculateAge(dateOfBirth: Date): number {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    return age;
  }
}
