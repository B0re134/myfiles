# BetPlatform - Production-Grade Sports Betting Platform

A complete, compliance-ready betting platform built with modern technologies and legal considerations.

## ⚖️ LEGAL DISCLAIMER

**This platform is for educational/demonstration purposes.** Operating a real betting platform requires:
- Gambling licenses (Malta, Curacao, UK, etc.)  
- Legal counsel specializing in gambling law
- Compliance officer
- Age verification systems
- KYC/AML procedures
- Responsible gambling tools
- Payment processor relationships

**Do NOT deploy for real money without proper licensing and legal approval.**

---

## 🚀 Technology Stack

### Backend
- **Runtime**: Node.js 20+ with TypeScript
- **Framework**: Express.js
- **Database**: PostgreSQL with Prisma ORM
- **Cache**: Redis
- **Real-time**: Socket.IO
- **Authentication**: JWT with refresh tokens
- **Security**: Helmet, rate limiting, input validation

### Frontend
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **State Management**: Zustand
- **HTTP Client**: Axios
- **Routing**: React Router v6

---

## 📋 Features

### User Features
✅ Registration with age verification  
✅ KYC document upload and verification  
✅ Multi-currency wallet system  
✅ Deposit/withdrawal management  
✅ Transaction history  
✅ Responsible gambling limits (deposit, loss, time)  
✅ Self-exclusion periods  
✅ Session management across devices  

### Admin Features
✅ Dashboard with analytics  
✅ User management  
✅ KYC approval/rejection workflow  
✅ Withdrawal approvals  
✅ Audit log viewing  
✅ Risk flagging system  
✅ User status management (suspend, ban)  

### Compliance Features
✅ Complete audit trail for all actions  
✅ KYC verification workflow  
✅ Deposit/loss limits enforcement  
✅ Session timeout controls  
✅ IP and device tracking  
✅ Age verification (18+ minimum)  
✅ GDPR-compliant data handling  

---

## 🛠️ Quick Start

### Prerequisites
- Node.js 20+
- PostgreSQL 14+
- Redis 7+
- Docker & Docker Compose (optional)

### Option 1: Docker (Recommended)

```bash
# Clone repository
git clone <your-repo-url>
cd betting-platform

# Start all services
docker-compose up

# In another terminal, run database migrations
docker-compose exec backend npx prisma migrate dev

# Create admin user (run in backend container)
docker-compose exec backend npm run create-admin
```

Access:
- Frontend: http://localhost:5173
- Backend: http://localhost:5000
- Database: localhost:5432

### Option 2: Manual Setup

#### 1. Setup Backend

```bash
cd backend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Edit .env with your configuration
nano .env

# Run database migrations
npx prisma migrate dev

# Generate Prisma client
npx prisma generate

# Start backend
npm run dev
```

#### 2. Setup Frontend

```bash
cd frontend

# Install dependencies
npm install

# Create .env file
echo "VITE_API_URL=http://localhost:5000/api" > .env

# Start frontend
npm run dev
```

---

## 📁 Project Structure

```
betting-platform/
├── backend/
│   ├── src/
│   │   ├── config/          # Database, Redis, etc.
│   │   ├── controllers/     # Route handlers
│   │   ├── middleware/      # Auth, validation, errors
│   │   ├── routes/          # API routes
│   │   ├── services/        # Business logic
│   │   ├── utils/           # Helpers, logger
│   │   └── server.ts        # Entry point
│   ├── prisma/
│   │   └── schema.prisma    # Database schema
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── components/      # Reusable UI components
│   │   ├── pages/           # Page components
│   │   ├── services/        # API client
│   │   ├── stores/          # State management
│   │   └── App.tsx
│   └── package.json
└── docker-compose.yml
```

---

## 🗄️ Database Schema

The platform includes 13 comprehensive models:

- **User**: Authentication, profile, compliance settings
- **Wallet**: Balance, transaction totals
- **Transaction**: All financial movements
- **Sport**: Sports categories
- **Match**: Game/event details
- **Market**: Betting markets (1X2, Over/Under, etc.)
- **Bet**: User bets with status tracking
- **KYCDocument**: Verification documents
- **Session**: JWT session management
- **AuditLog**: Complete audit trail

---

## 🔐 Security Features

- **Authentication**: JWT access + refresh tokens
- **Session Management**: Multi-device tracking, logout all
- **Rate Limiting**: Configurable per endpoint
- **Input Validation**: express-validator on all inputs
- **SQL Injection Protection**: Prisma parameterized queries
- **XSS Protection**: Helmet.js security headers
- **CORS**: Configured for frontend origin
- **Password Hashing**: bcrypt with configurable rounds

---

## 🎯 Default User Roles

Create users via registration or admin promotion:

### Regular User
- Can bet, deposit, withdraw (with KYC)
- Subject to responsible gambling limits

### Admin
- View dashboard analytics
- Manage users and KYC
- Approve withdrawals
- View audit logs

### Super Admin
- All admin permissions
- Can promote other admins

---

## 🔧 Environment Variables

### Backend (.env)

```env
# Application
NODE_ENV=development
PORT=5000
CLIENT_URL=http://localhost:5173

# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/betting_platform

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# JWT
JWT_SECRET=your-secret-key
JWT_REFRESH_SECRET=your-refresh-secret
JWT_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d

# Compliance
MIN_AGE=18
KYC_REQUIRED_FOR_WITHDRAWAL=true
MAX_DEPOSIT_WITHOUT_KYC=1000
```

### Frontend (.env)

```env
VITE_API_URL=http://localhost:5000/api
```

---

## 📊 API Endpoints

### Authentication
```
POST /api/auth/register       # Register new user
POST /api/auth/login          # Login
POST /api/auth/refresh        # Refresh access token
POST /api/auth/logout         # Logout current session
POST /api/auth/logout-all     # Logout all sessions
GET  /api/auth/me             # Get current user
```

### Wallet
```
GET  /api/wallet              # Get wallet details
GET  /api/wallet/balance      # Get balance
POST /api/wallet/deposit      # Deposit funds
POST /api/wallet/withdraw     # Request withdrawal
GET  /api/wallet/transactions # Transaction history
```

### Admin (requires ADMIN/SUPER_ADMIN role)
```
GET  /api/admin/dashboard/stats       # Dashboard analytics
GET  /api/admin/users                 # List users
GET  /api/admin/users/:id             # User details
PATCH /api/admin/users/:id/status     # Update status
POST /api/admin/users/:id/kyc/approve # Approve KYC
POST /api/admin/users/:id/kyc/reject  # Reject KYC
GET  /api/admin/audit-logs            # View audit logs
POST /api/admin/transactions/:id/approve # Approve withdrawal
```

---

## 🚀 Deployment Checklist

### Pre-Deployment

- [ ] Obtain gambling license for target jurisdiction
- [ ] Set up licensed payment processors
- [ ] Contract with odds data provider (Sportradar, etc.)
- [ ] Configure SMTP for email notifications
- [ ] Set up file storage (Cloudinary, S3)
- [ ] Review and update all security settings
- [ ] Configure production database with backups
- [ ] Set up monitoring (Sentry, DataDog)
- [ ] Implement CDN for frontend assets
- [ ] SSL certificates for all domains

### Production Environment Variables

All secrets must be changed from defaults:
- Generate strong JWT secrets (32+ characters)
- Use production database credentials
- Configure real payment provider API keys
- Set up production Redis instance
- Configure email service (SendGrid, AWS SES)

### Database

```bash
# Production migration
npx prisma migrate deploy

# Do NOT use migrate dev in production
```

---

## 🧪 Testing

```bash
# Backend tests (when implemented)
cd backend
npm test

# Frontend tests (when implemented)
cd frontend
npm test
```

---

## 📝 License Compliance

This software is provided as-is for educational purposes. Users are responsible for:
- Obtaining all necessary gambling licenses
- Compliance with local and international gambling laws
- Data protection regulations (GDPR, CCPA, etc.)
- Age verification requirements
- Responsible gambling implementations
- AML/KYC procedures

---

## 🤝 Contributing

This is a demonstration platform. For production use:
1. Consult with gambling law specialists
2. Implement jurisdiction-specific requirements
3. Add comprehensive testing
4. Security audit by professionals
5. Penetration testing
6. Load testing for production scale

---

## 📞 Support

For educational/technical questions only.  
For legal/compliance questions, consult a gambling law attorney.

---

## ⚡ Next Steps (Phase 2-4)

**Phase 2: Sports & Betting Engine**
- Integration with odds provider API
- Live match data synchronization
- Bet placement validation
- Settlement automation
- Cash-out functionality

**Phase 3: Payment Integration**
- Stripe/payment provider integration
- Cryptocurrency support
- Automated withdrawal processing
- Payment reconciliation

**Phase 4: Advanced Features**
- Live betting with WebSocket
- Mobile app (React Native/Capacitor)
- Advanced analytics dashboard
- Recommendation engine
- Multi-language support

---

**Built with compliance and security in mind. Use responsibly and legally.**
