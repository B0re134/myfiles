import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Users, DollarSign, TrendingUp, AlertTriangle } from 'lucide-react';

export default function AdminDashboard() {
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [statsRes, usersRes] = await Promise.all([
        api.getDashboardStats(),
        api.getUsers({ limit: 20 }),
      ]);
      setStats(statsRes.data);
      setUsers(usersRes.data.users);
    } catch (error) {
      console.error('Failed to load admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApproveKYC = async (userId: string) => {
    if (!confirm('Approve KYC for this user?')) return;
    try {
      await api.approveKYC(userId);
      await loadData();
    } catch (error) {
      console.error('Failed to approve KYC:', error);
    }
  };

  const handleUpdateStatus = async (userId: string, status: string) => {
    if (!confirm(`Change user status to ${status}?`)) return;
    try {
      await api.updateUserStatus(userId, status);
      await loadData();
    } catch (error) {
      console.error('Failed to update status:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-display font-bold text-white">Admin Dashboard</h1>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="card bg-gradient-to-br from-brand-900/50 to-brand-950/50 border-brand-800">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-brand-500/20 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-brand-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Total Users</p>
              <p className="text-2xl font-bold text-white">{stats?.users?.total || 0}</p>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Active Users</p>
              <p className="text-2xl font-bold text-white">{stats?.users?.active || 0}</p>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-yellow-500/20 rounded-xl flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Pending KYC</p>
              <p className="text-2xl font-bold text-white">{stats?.users?.pendingKYC || 0}</p>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Today Deposits</p>
              <p className="text-2xl font-bold text-white">
                ${parseFloat(stats?.today?.deposits?.amount || '0').toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Users Table */}
      <div className="card">
        <h2 className="text-xl font-display font-bold text-white mb-4">Recent Users</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left py-3 text-sm font-medium text-gray-400">Email</th>
                <th className="text-left py-3 text-sm font-medium text-gray-400">Name</th>
                <th className="text-left py-3 text-sm font-medium text-gray-400">Status</th>
                <th className="text-left py-3 text-sm font-medium text-gray-400">KYC</th>
                <th className="text-left py-3 text-sm font-medium text-gray-400">Balance</th>
                <th className="text-left py-3 text-sm font-medium text-gray-400">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id} className="border-b border-gray-800/50">
                  <td className="py-3 text-sm text-white">{user.email}</td>
                  <td className="py-3 text-sm text-white">
                    {user.firstName} {user.lastName}
                  </td>
                  <td className="py-3">
                    <span className={
                      user.status === 'ACTIVE' ? 'badge badge-success' :
                      user.status === 'PENDING_VERIFICATION' ? 'badge badge-warning' :
                      'badge badge-error'
                    }>
                      {user.status}
                    </span>
                  </td>
                  <td className="py-3">
                    <span className={
                      user.kycStatus === 'APPROVED' ? 'badge badge-success' :
                      user.kycStatus === 'PENDING' ? 'badge badge-warning' :
                      'badge badge-info'
                    }>
                      {user.kycStatus}
                    </span>
                  </td>
                  <td className="py-3 text-sm text-white font-mono">
                    ${parseFloat(user.wallet?.balance || '0').toFixed(2)}
                  </td>
                  <td className="py-3">
                    <div className="flex gap-2">
                      {user.kycStatus === 'PENDING' && (
                        <button
                          onClick={() => handleApproveKYC(user.id)}
                          className="text-xs btn btn-success"
                        >
                          Approve KYC
                        </button>
                      )}
                      {user.status === 'ACTIVE' && (
                        <button
                          onClick={() => handleUpdateStatus(user.id, 'SUSPENDED')}
                          className="text-xs btn btn-danger"
                        >
                          Suspend
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
