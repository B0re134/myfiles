import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Wallet, ArrowDownCircle, ArrowUpCircle, AlertCircle, CheckCircle } from 'lucide-react';

export default function WalletPage() {
  const [wallet, setWallet] = useState<any>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDeposit, setShowDeposit] = useState(false);
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('CREDIT_CARD');
  const [processing, setProcessing] = useState(false);
  const [message, setMessage] = useState<{ type: string; text: string } | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [walletRes, transactionsRes] = await Promise.all([
        api.getWallet(),
        api.getTransactions({ limit: 20 }),
      ]);
      setWallet(walletRes.data.wallet);
      setTransactions(transactionsRes.data.transactions);
    } catch (error) {
      console.error('Failed to load wallet data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);
    setMessage(null);

    try {
      await api.deposit({ amount: parseFloat(amount), paymentMethod });
      setMessage({ type: 'success', text: 'Deposit successful!' });
      setShowDeposit(false);
      setAmount('');
      await loadData();
    } catch (error: any) {
      setMessage({
        type: 'error',
        text: error.response?.data?.message || 'Deposit failed',
      });
    } finally {
      setProcessing(false);
    }
  };

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);
    setMessage(null);

    try {
      await api.withdraw({ amount: parseFloat(amount), paymentMethod });
      setMessage({
        type: 'success',
        text: 'Withdrawal request submitted (pending approval)',
      });
      setShowWithdraw(false);
      setAmount('');
      await loadData();
    } catch (error: any) {
      setMessage({
        type: 'error',
        text: error.response?.data?.message || 'Withdrawal failed',
      });
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-display font-bold text-white">Wallet</h1>
        <div className="flex gap-3">
          <button
            onClick={() => setShowDeposit(true)}
            className="btn btn-primary flex items-center gap-2"
          >
            <ArrowDownCircle className="w-5 h-5" />
            Deposit
          </button>
          <button
            onClick={() => setShowWithdraw(true)}
            className="btn btn-secondary flex items-center gap-2"
          >
            <ArrowUpCircle className="w-5 h-5" />
            Withdraw
          </button>
        </div>
      </div>

      {message && (
        <div className={`card ${message.type === 'success' ? 'bg-green-900/20 border-green-800' : 'bg-red-900/20 border-red-800'}`}>
          <div className="flex items-start gap-3">
            {message.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            )}
            <p className={message.type === 'success' ? 'text-green-400' : 'text-red-400'}>
              {message.text}
            </p>
          </div>
        </div>
      )}

      {/* Balance Card */}
      <div className="card bg-gradient-to-br from-brand-900/50 to-brand-950/50 border-brand-800">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 bg-brand-500/20 rounded-2xl flex items-center justify-center">
            <Wallet className="w-8 h-8 text-brand-400" />
          </div>
          <div>
            <p className="text-sm text-gray-400 mb-1">Current Balance</p>
            <p className="text-4xl font-bold text-white">
              ${parseFloat(wallet?.balance || '0').toFixed(2)}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 pt-4 border-t border-brand-800/50">
          <div>
            <p className="text-xs text-gray-400 mb-1">Total Deposited</p>
            <p className="text-lg font-semibold text-white">
              ${parseFloat(wallet?.totalDeposited || '0').toFixed(2)}
            </p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-1">Total Withdrawn</p>
            <p className="text-lg font-semibold text-white">
              ${parseFloat(wallet?.totalWithdrawn || '0').toFixed(2)}
            </p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-1">Total Wagered</p>
            <p className="text-lg font-semibold text-white">
              ${parseFloat(wallet?.totalWagered || '0').toFixed(2)}
            </p>
          </div>
        </div>
      </div>

      {/* Transaction History */}
      <div className="card">
        <h2 className="text-xl font-display font-bold text-white mb-4">Transaction History</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left py-3 text-sm font-medium text-gray-400">Type</th>
                <th className="text-left py-3 text-sm font-medium text-gray-400">Amount</th>
                <th className="text-left py-3 text-sm font-medium text-gray-400">Status</th>
                <th className="text-left py-3 text-sm font-medium text-gray-400">Method</th>
                <th className="text-left py-3 text-sm font-medium text-gray-400">Date</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((tx) => (
                <tr key={tx.id} className="border-b border-gray-800/50">
                  <td className="py-3 text-sm text-white">{tx.type}</td>
                  <td className="py-3 text-sm text-white font-mono">
                    ${parseFloat(tx.amount).toFixed(2)}
                  </td>
                  <td className="py-3">
                    <span className={
                      tx.status === 'COMPLETED' ? 'badge badge-success' :
                      tx.status === 'PENDING' ? 'badge badge-warning' :
                      'badge badge-error'
                    }>
                      {tx.status}
                    </span>
                  </td>
                  <td className="py-3 text-sm text-gray-400">{tx.paymentMethod || 'N/A'}</td>
                  <td className="py-3 text-sm text-gray-400">
                    {new Date(tx.createdAt).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Deposit Modal */}
      {showDeposit && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="card max-w-md w-full">
            <h3 className="text-xl font-bold text-white mb-4">Deposit Funds</h3>
            <form onSubmit={handleDeposit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Amount</label>
                <input
                  type="number"
                  required
                  min="1"
                  step="0.01"
                  className="input"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="100.00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Payment Method</label>
                <select
                  className="input"
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                >
                  <option value="CREDIT_CARD">Credit Card</option>
                  <option value="DEBIT_CARD">Debit Card</option>
                  <option value="BANK_TRANSFER">Bank Transfer</option>
                  <option value="CRYPTO">Cryptocurrency</option>
                </select>
              </div>
              <div className="flex gap-3">
                <button type="submit" disabled={processing} className="btn btn-primary flex-1">
                  {processing ? 'Processing...' : 'Deposit'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowDeposit(false)}
                  className="btn btn-secondary flex-1"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Withdraw Modal */}
      {showWithdraw && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="card max-w-md w-full">
            <h3 className="text-xl font-bold text-white mb-4">Withdraw Funds</h3>
            <form onSubmit={handleWithdraw} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Amount</label>
                <input
                  type="number"
                  required
                  min="1"
                  step="0.01"
                  className="input"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="100.00"
                />
                <p className="text-xs text-gray-400 mt-1">
                  Available: ${parseFloat(wallet?.balance || '0').toFixed(2)}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Payment Method</label>
                <select
                  className="input"
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                >
                  <option value="BANK_TRANSFER">Bank Transfer</option>
                  <option value="CRYPTO">Cryptocurrency</option>
                </select>
              </div>
              <div className="flex gap-3">
                <button type="submit" disabled={processing} className="btn btn-primary flex-1">
                  {processing ? 'Processing...' : 'Withdraw'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowWithdraw(false)}
                  className="btn btn-secondary flex-1"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
