import { useEffect, useState } from 'react';
import { useAuthStore } from '../stores/authStore';
import { api } from '../services/api';
import { Wallet, TrendingUp, Clock, AlertCircle, CheckCircle } from 'lucide-react';

export default function Dashboard() {
  const { user } = useAuthStore();
  const [wallet, setWallet] = useState<any>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [walletRes, transactionsRes] = await Promise.all([
        api.getWallet(),
        api.getTransactions({ limit: 10 }),
      ]);
      setWallet(walletRes.data.wallet);
      setTransactions(transactionsRes.data.transactions);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const badges: Record<string, string> = {
      ACTIVE: 'badge badge-success',
      PENDING_VERIFICATION: 'badge badge-warning',
      SUSPENDED: 'badge badge-error',
    };
    return badges[status] || 'badge badge-info';
  };

  const getKYCBadge = (status: string) => {
    const badges: Record<string, string> = {
      APPROVED: 'badge badge-success',
      PENDING: 'badge badge-warning',
      NOT_SUBMITTED: 'badge badge-info',
      REJECTED: 'badge badge-error',
    };
    return badges[status] || 'badge badge-info';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="card">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-display font-bold text-white mb-2">
              Welcome back, {user?.firstName}!
            </h1>
            <p className="text-gray-400">Here's your account overview</p>
          </div>
          <div className="flex gap-2">
            <span className={getStatusBadge(user?.status || '')}>
              {user?.status}
            </span>
            <span className={getKYCBadge(user?.kycStatus || '')}>
              KYC: {user?.kycStatus}
            </span>
          </div>
        </div>
      </div>

      {/* KYC Warning */}
      {user?.kycStatus !== 'APPROVED' && (
        <div className="card bg-yellow-900/20 border-yellow-800">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-yellow-400 font-semibold mb-1">KYC Verification Required</h3>
              <p className="text-gray-300 text-sm">
                Complete KYC verification to unlock withdrawals and higher deposit limits.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card bg-gradient-to-br from-brand-900/50 to-brand-950/50 border-brand-800">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-brand-500/20 rounded-xl flex items-center justify-center">
              <Wallet className="w-6 h-6 text-brand-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Balance</p>
              <p className="text-2xl font-bold text-white">
                ${parseFloat(wallet?.balance || '0').toFixed(2)}
              </p>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Total Deposited</p>
              <p className="text-2xl font-bold text-white">
                ${parseFloat(wallet?.totalDeposited || '0').toFixed(2)}
              </p>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
              <Clock className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Total Wagered</p>
              <p className="text-2xl font-bold text-white">
                ${parseFloat(wallet?.totalWagered || '0').toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="card">
        <h2 className="text-xl font-display font-bold text-white mb-4">Recent Transactions</h2>
        {transactions.length === 0 ? (
          <p className="text-gray-400 text-center py-8">No transactions yet</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left py-3 text-sm font-medium text-gray-400">Type</th>
                  <th className="text-left py-3 text-sm font-medium text-gray-400">Amount</th>
                  <th className="text-left py-3 text-sm font-medium text-gray-400">Status</th>
                  <th className="text-left py-3 text-sm font-medium text-gray-400">Date</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx) => (
                  <tr key={tx.id} className="border-b border-gray-800/50">
                    <td className="py-3 text-sm text-white">{tx.type}</td>
                    <td className="py-3 text-sm text-white font-mono">
                      ${parseFloat(tx.amount).toFixed(2)}
                    </td>
                    <td className="py-3">
                      <span className={
                        tx.status === 'COMPLETED' ? 'badge badge-success' :
                        tx.status === 'PENDING' ? 'badge badge-warning' :
                        'badge badge-error'
                      }>
                        {tx.status}
                      </span>
                    </td>
                    <td className="py-3 text-sm text-gray-400">
                      {new Date(tx.createdAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
