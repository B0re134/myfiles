import axios, { AxiosError, AxiosInstance } from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

class ApiService {
  private api: AxiosInstance;

  constructor() {
    this.api = axios.create({
      baseURL: API_BASE_URL,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Request interceptor to add token
    this.api.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('accessToken');
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor to handle token refresh
    this.api.interceptors.response.use(
      (response) => response,
      async (error: AxiosError) => {
        const originalRequest = error.config as any;

        if (error.response?.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true;

          try {
            const refreshToken = localStorage.getItem('refreshToken');
            if (!refreshToken) throw new Error('No refresh token');

            const { data } = await axios.post(`${API_BASE_URL}/auth/refresh`, {
              refreshToken,
            });

            localStorage.setItem('accessToken', data.data.tokens.accessToken);
            localStorage.setItem('refreshToken', data.data.tokens.refreshToken);

            originalRequest.headers.Authorization = `Bearer ${data.data.tokens.accessToken}`;
            return this.api(originalRequest);
          } catch (refreshError) {
            localStorage.clear();
            window.location.href = '/login';
            return Promise.reject(refreshError);
          }
        }

        return Promise.reject(error);
      }
    );
  }

  // Auth
  async register(data: any) {
    const response = await this.api.post('/auth/register', data);
    return response.data;
  }

  async login(data: any) {
    const response = await this.api.post('/auth/login', data);
    return response.data;
  }

  async logout() {
    const response = await this.api.post('/auth/logout');
    return response.data;
  }

  async getMe() {
    const response = await this.api.get('/auth/me');
    return response.data;
  }

  // Wallet
  async getWallet() {
    const response = await this.api.get('/wallet');
    return response.data;
  }

  async getBalance() {
    const response = await this.api.get('/wallet/balance');
    return response.data;
  }

  async deposit(data: any) {
    const response = await this.api.post('/wallet/deposit', data);
    return response.data;
  }

  async withdraw(data: any) {
    const response = await this.api.post('/wallet/withdraw', data);
    return response.data;
  }

  async getTransactions(params?: any) {
    const response = await this.api.get('/wallet/transactions', { params });
    return response.data;
  }

  // Admin
  async getDashboardStats() {
    const response = await this.api.get('/admin/dashboard/stats');
    return response.data;
  }

  async getUsers(params?: any) {
    const response = await this.api.get('/admin/users', { params });
    return response.data;
  }

  async getUser(userId: string) {
    const response = await this.api.get(`/admin/users/${userId}`);
    return response.data;
  }

  async updateUserStatus(userId: string, status: string) {
    const response = await this.api.patch(`/admin/users/${userId}/status`, { status });
    return response.data;
  }

  async approveKYC(userId: string) {
    const response = await this.api.post(`/admin/users/${userId}/kyc/approve`);
    return response.data;
  }

  async rejectKYC(userId: string, reason: string) {
    const response = await this.api.post(`/admin/users/${userId}/kyc/reject`, { reason });
    return response.data;
  }

  async getAuditLogs(params?: any) {
    const response = await this.api.get('/admin/audit-logs', { params });
    return response.data;
  }

  async approveWithdrawal(transactionId: string) {
    const response = await this.api.post(`/admin/transactions/${transactionId}/approve`);
    return response.data;
  }
}

export const api = new ApiService();
